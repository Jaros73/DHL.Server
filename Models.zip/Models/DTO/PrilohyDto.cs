﻿namespace DHL.Server.Models.DTO
{
    public class PrilohyDto
    {
        public string Filename { get; set; } = string.Empty;
        public string DisplayName { get; set; } = string.Empty;
    }
}
