﻿using AutoMapper;
using DHL.Server.Features.Ciselniky.Models;
using DHL.Server.Models.DTO;
using DHL.Server.Models.Entities;

namespace DHL.Server.Models.Profiles
{
    /// <summary>
    /// Konfigurace mapování Entity -> DTO.
    /// </summary>
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<LocationEntity, Location>();
            CreateMap<DispatchTypeEntity, DispatchType>();
            CreateMap<DispatchKeyEntity, DispatchKey>();
            CreateMap<KurzEntity, KurzDto>().ReverseMap();
            CreateMap<IrregularCourseEntity, MimKurzDto>().ReverseMap();
            CreateMap<MachiningEntity, VykonStrojDto>().ReverseMap();
            CreateMap<RegionalReportEntity, RegionalReportDto>().ReverseMap();
            CreateMap<RemainderEntity, ZbytekDto>().ReverseMap();
            CreateMap<AttachmentEntity, PrilohyDto>().ReverseMap();
            CreateMap<KurzyPEEntity, KurzyPEDto>().ReverseMap();
            CreateMap<ZatezAPEntity, ZatezAPDto>().ReverseMap();
            CreateMap<ZpozdeniKurzuEntity, ZpozdeniKurzuDto>().ReverseMap();
            CreateMap<TransporterEntity, PrepravceDto>().ReverseMap();
            CreateMap<StopEntity, ZastavkaDto>().ReverseMap();
            CreateMap<VehicleEntity, VozidloDto>().ReverseMap();
            CreateMap<TrailerEntity, PripojVozidloDto>().ReverseMap();
            CreateMap<KlicEntity, KlicDto>().ReverseMap();
        }
    }
}
